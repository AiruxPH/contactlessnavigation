# Grading System Implementation Instructions

Create flask python api web application in grading system.

Design 5 html templates with 1 dashboard and 4 subjects.

Each subject contains 5 quizes and 1 exam as input where exam is 60% and total quizes is 40% in the total grade.

Display the grade with the remarks as grade A for 95-100, B for 90-94, C for 85-89, D for 80-84, E 75-79 and F for Failed.

Dashboard will display the subject selection and the total average grade of the 4 subjects.

Routes all subjects in your python file
