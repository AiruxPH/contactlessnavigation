from flask import Flask, render_template, request, redirect, url_for, send_from_directory, session, flash
import json
import os
import secrets
from datetime import datetime

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)
USERS_FILE = 'database/users.json'

def load_users():
    if not os.path.exists(USERS_FILE):
        return {}
    try:
        with open(USERS_FILE, 'r') as f:
            return json.load(f)
    except (json.JSONDecodeError, ValueError):
        return {}

def save_users(users):
    if not os.path.exists('database'):
        os.makedirs('database')
    with open(USERS_FILE, 'w') as f:
        json.dump(users, f, indent=4)

# Global storage for grades (in a real app, use a database or session)
grades = {
    'sub1': {'score': 0, 'remark': 'N/A'},
    'sub2': {'score': 0, 'remark': 'N/A'},
    'sub3': {'score': 0, 'remark': 'N/A'},
    'sub4': {'score': 0, 'remark': 'N/A'}
}

def get_remark(score):
    if score >= 95: return 'A'
    elif score >= 90: return 'B'
    elif score >= 85: return 'C'
    elif score >= 80: return 'D'
    elif score >= 75: return 'E'
    else: return 'Failed'


def log_error_to_json(error_message):
    log_file = 'logs.json'
    error_entry = {
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'message': str(error_message),
        'path': request.path,
        'method': request.method
    }
    
    logs = []
    if os.path.exists(log_file):
        try:
            with open(log_file, 'r') as f:
                logs = json.load(f)
        except (json.JSONDecodeError, ValueError):
            logs = []
            
    logs.append(error_entry)
    
    with open(log_file, 'w') as f:
        json.dump(logs, f, indent=4)


@app.errorhandler(Exception)
def handle_exception(e):
    # Log the error
    log_error_to_json(e)
    # Return a basic error message or template
    return "An internal error occurred. It has been logged.", 500


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        code = str(secrets.randbelow(899999) + 100000)
        
        users = load_users()
        if email in users:
            flash("Email already registered.", "error")
            return redirect(url_for('register'))
            
        users[email] = {
            'password': password,
            'is_verified': 0,
            'verification_code': code
        }
        save_users(users)
        
        print(f"\n[EMAIL SIMULATION] Verification code for {email}: {code}\n")
        
        session['temp_email'] = email
        return redirect(url_for('verify'))
            
    return render_template('register.html')


@app.route('/verify', methods=['GET', 'POST'])
def verify():
    if request.method == 'POST':
        code = request.form.get('code')
        email = session.get('temp_email')
        
        users = load_users()
        user = users.get(email)
        
        if user and user['verification_code'] == code:
            user['is_verified'] = 1
            save_users(users)
            session.pop('temp_email', None)
            return redirect(url_for('login'))
        else:
            flash("Invalid code.", "error")
            return redirect(url_for('verify'))
            
    return render_template('verify.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        users = load_users()
        user = users.get(email)
        
        if user and user['password'] == password:
            if user['is_verified'] == 1:
                session['user_id'] = email # Using email as ID for JSON setup
                session['email'] = email
                return redirect(url_for('dashboard'))
            else:
                session['temp_email'] = email
                return redirect(url_for('verify'))
        else:
            flash("Invalid credentials.", "error")
            return redirect(url_for('login'))
            
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


@app.before_request
def check_auth():
    # Only protect specific routes
    protected_routes = ['dashboard', 'sub1', 'sub2', 'sub3', 'sub4']
    if request.endpoint in protected_routes and 'user_id' not in session:
        return redirect(url_for('login'))


@app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(app.root_path, 'static'),
                               'favicon.ico', mimetype='image/vnd.microsoft.icon')


@app.route('/')
@app.route('/dashboard')
def dashboard():
    # Basic addition instead of sum() with generator
    s1 = grades['sub1']['score']
    s2 = grades['sub2']['score']
    s3 = grades['sub3']['score']
    s4 = grades['sub4']['score']
    
    overall_avg = (s1 + s2 + s3 + s4) / 4
    overall_avg = round(overall_avg, 2)
    
    return render_template('dashboard.html', grades=grades, overall_avg=overall_avg)


@app.route('/sub1', methods=['GET', 'POST'])
def sub1():
    if request.method == 'POST':
        try:
            # Fetch values explicitly
            q1 = float(request.form.get('q1', 0))
            q2 = float(request.form.get('q2', 0))
            q3 = float(request.form.get('q3', 0))
            q4 = float(request.form.get('q4', 0))
            q5 = float(request.form.get('q5', 0))
            exam = float(request.form.get('exam', 0))
            
            # Basic math calculation
            quiz_avg = (q1 + q2 + q3 + q4 + q5) / 5
            total_grade = (quiz_avg * 0.4) + (exam * 0.6)
            
            # Update storage directly
            grades['sub1']['score'] = round(total_grade, 2)
            grades['sub1']['remark'] = get_remark(total_grade)
        except ValueError:
            pass
        return redirect(url_for('dashboard'))
    return render_template('Subject1.html')


@app.route('/sub2', methods=['GET', 'POST'])
def sub2():
    if request.method == 'POST':
        try:
            q1 = float(request.form.get('q1', 0))
            q2 = float(request.form.get('q2', 0))
            q3 = float(request.form.get('q3', 0))
            q4 = float(request.form.get('q4', 0))
            q5 = float(request.form.get('q5', 0))
            exam = float(request.form.get('exam', 0))
            
            quiz_avg = (q1 + q2 + q3 + q4 + q5) / 5
            total_grade = (quiz_avg * 0.4) + (exam * 0.6)
            
            grades['sub2']['score'] = round(total_grade, 2)
            grades['sub2']['remark'] = get_remark(total_grade)
        except ValueError:
            pass
        return redirect(url_for('dashboard'))
    return render_template('Subject2.html')


@app.route('/sub3', methods=['GET', 'POST'])
def sub3():
    if request.method == 'POST':
        try:
            q1 = float(request.form.get('q1', 0))
            q2 = float(request.form.get('q2', 0))
            q3 = float(request.form.get('q3', 0))
            q4 = float(request.form.get('q4', 0))
            q5 = float(request.form.get('q5', 0))
            exam = float(request.form.get('exam', 0))
            
            quiz_avg = (q1 + q2 + q3 + q4 + q5) / 5
            total_grade = (quiz_avg * 0.4) + (exam * 0.6)
            
            grades['sub3']['score'] = round(total_grade, 2)
            grades['sub3']['remark'] = get_remark(total_grade)
        except ValueError:
            pass
        return redirect(url_for('dashboard'))
    return render_template('Subject3.html')


@app.route('/sub4', methods=['GET', 'POST'])
def sub4():
    if request.method == 'POST':
        try:
            q1 = float(request.form.get('q1', 0))
            q2 = float(request.form.get('q2', 0))
            q3 = float(request.form.get('q3', 0))
            q4 = float(request.form.get('q4', 0))
            q5 = float(request.form.get('q5', 0))
            exam = float(request.form.get('exam', 0))
            
            quiz_avg = (q1 + q2 + q3 + q4 + q5) / 5
            total_grade = (quiz_avg * 0.4) + (exam * 0.6)
            
            grades['sub4']['score'] = round(total_grade, 2)
            grades['sub4']['remark'] = get_remark(total_grade)
        except ValueError:
            pass
        return redirect(url_for('dashboard'))
    return render_template('Subject4.html')

if __name__ == '__main__':
    app.run(debug=True)