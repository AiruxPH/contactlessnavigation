# Changelog

All notable changes to this project will be documented in this file.

## [1.1.0] - 2026-03-12

### Added
- Created `static/css/style.css` with a premium modern design system (Slate/Indigo theme).
- Added Google Fonts integration (Inter & Outfit).

- Implemented user-friendly error alerts using Flask's flash messaging system.
- Added a new `.alert` CSS class in `style.css` for consistent error styling across authentication pages.
- Downgraded user authentication system to use a lightweight `users.json` file instead of SQLite.
- Removed SQLite database (`database.db`) and related database connections to further simplify the application.
- Added JSON-based error logging system (`logs.json`) to persist application errors.
- Refactored `app.py` to use basic Python fundamentals by removing logic abstractions (helper functions) and complex expressions.
- Added explicit variable assignments for quizzes and dashboard averages for better transparency.

- Refactored `dashboard.html` with a modern card-based layout and interactive elements.
- Downgraded the UI to a "Beginner-friendly" level, using basic HTML tables and simple CSS layouts.
- Removed advanced styling features like Google Fonts, gradients, and professional themes for a more fundamental appearance.


### Checked
- Full alignment with `instructions.md`.
- Responsive design across all pages.
- Consistency of design system tokens.


